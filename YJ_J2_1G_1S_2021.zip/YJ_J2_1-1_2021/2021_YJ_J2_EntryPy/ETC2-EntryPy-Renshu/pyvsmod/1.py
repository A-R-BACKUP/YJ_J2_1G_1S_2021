i = 0
sum = 0

for i in range(1, 11, 1):
    sum = sum+1

print("%d" % sum)
