i = 0
sum = 0

i = 1
while i < 11:
    sum = sum + i
    i = i + 1

print("%d" % sum)
